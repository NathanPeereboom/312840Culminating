﻿/* Nathan Peereboom
 * June 19, 2019
 * Culminating Project: Fighting game
 * Main Window
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.Media;
using System.IO;
using System.Windows.Threading;

namespace _312840Culminating
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Classes
        
        Player[] player = new Player[2];
        
        DispatcherTimer gameTimer = new DispatcherTimer();
        Hitbox[] hitbox = new Hitbox[2];
        Rect[] hitboxRect = new Rect[2];
        Rect[] hurtBox = new Rect[2];
        Rectangle[] hurtBoxDisplay = new Rectangle[2];
        Rectangle[] lifebar = new Rectangle[2];
        
        public MainWindow()
        {
            InitializeComponent();

            //game timer
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Interval = new TimeSpan(0, 0, 0, 0, 17);
            gameTimer.Start();

            //players
            player[0] = new Player(1, Key.A, Key.D, Key.W, Key.S, Key.D1, Key.D2);
            player[1] = new Player(2, Key.Left, Key.Right, Key.Up, Key.Down, Key.OemComma, Key.OemPeriod);

            player[0].generate(canvas);
            player[1].generate(canvas);

            //detection boxes
            for (int i = 0; i < 2; i++)
            {
                hurtBox[i] = new Rect();
                hurtBoxDisplay[i] = new Rectangle();
                //canvas.Children.Add(hurtBoxDisplay[i]);
                hitbox[i] = new Hitbox();
                hitboxRect[i] = new Rect();
                lifebar[i] = new Rectangle();
            }

            //lifebar (player 1)
            Canvas.SetTop(lifebar[0], 20);
            Canvas.SetLeft(lifebar[0], 40);
            lifebar[0].Height = 30;
            lifebar[0].Fill = Brushes.Red;
            canvas.Children.Add(lifebar[0]);

            //lifebar (player 2)
            Canvas.SetTop(lifebar[1], 20);
            Canvas.SetRight(lifebar[1], 40);
            lifebar[1].Height = 30;
            lifebar[1].Fill = Brushes.Blue;
            canvas.Children.Add(lifebar[1]);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            //Read controller inputs
            player[0].move();
            player[1].move();

            //Update players
            player[0].animate(player[1].getXPos(), player[1].getDirection());
            player[1].animate(player[0].getXPos(), player[0].getDirection());

            //Update hitboxes
            for (int i = 0; i < 2; i++)
            {
                hitbox[i] = player[i].getHitbox();
                hitboxRect[i] = player[i].getHitboxRect();
            }

            //Update hurtboxes
            for (int i = 0; i < 2; i++)
            {
                hurtBox[i].X = player[i].getXPos() + 42;
                hurtBox[i].Y = player[i].getYPos() + 35;
                hurtBox[i].Width = 44;
                hurtBox[i].Height = 90;

                /*hurtBoxDisplay[i].Opacity = .5;
                hurtBoxDisplay[i].Fill = Brushes.Purple;
                hurtBoxDisplay[i].Width = 44;
                hurtBoxDisplay[i].Height = 90;
                Canvas.SetLeft(hurtBoxDisplay[i], player[i].getXPos() + 42);
                Canvas.SetTop(hurtBoxDisplay[i], player[i].getYPos() + 35);*/
                
            }

            //Check for hit
            if (hitboxRect[0].IntersectsWith(hurtBox[1]) && !player[1].isDucking())
            {
                player[1].wasHit(hitbox[0].getDamage(), (int)hitbox[0].getKnockbackAngle(), hitbox[0].getKnockbackSpeed(), hitbox[0].getKnockbackDuration(), hitbox[0].getHitstunDuration());
            }
            if (hitboxRect[1].IntersectsWith(hurtBox[0]) && !player[0].isDucking())
            {
                player[0].wasHit(hitbox[1].getDamage(), (int)hitbox[1].getKnockbackAngle(), hitbox[1].getKnockbackSpeed(), hitbox[1].getKnockbackDuration(), hitbox[1].getHitstunDuration());
            }

            //Update lifebars
            lifebar[0].Width = 3 * player[0].getHealth();
            lifebar[1].Width = 3 * player[1].getHealth();

            //End game
            if (player[0].getHealth() == 0 && player[1].getHealth() > 0)
            {
                gameTimer.Stop();
                MessageBox.Show("Player 2 wins!");
            }

            if (player[1].getHealth() == 0 && player[0].getHealth() > 0)
            {
                gameTimer.Stop();
                MessageBox.Show("Player 1 wins!");
            }

            if (player[0].getHealth() == 0 && player[1].getHealth() == 0)
            {
                gameTimer.Stop();
                MessageBox.Show("Double KO! It's a tie!");
            }
        }
    }
}
