﻿/* Nathan Peereboom
 * June 19, 2019
 * Culminating Project: Fighting game
 * Player class
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _312840Culminating
{
    class Player
    {
        int player;//1 or 2

        //Controls
        Key leftButton;
        Key rightButton;
        Key upButton;
        Key downButton;
        Key punchButton;
        Key kickButton;
        
        //Movement variables
        double xPos;//Horizontal position from left
        double yPos;//Vertical position from top
        int direction;//-1 = facing left, 1 = facing right
        int walkAnimate;//Animation of the walking
        int jump;//How much longer the player goes up after jumping.
        bool inAir;//Is the player off the ground?
        bool falling;//Is the player falling towards the ground?

        //Action variables
        int action;//The action being performed by the player.
        bool lag;//Is the player doing an action which prohibits them from doing anything else until that action has ended?
        int animation;//How much longer the player is in lag.
        bool ducking;//Is the player ducking and invulnerable?

        //Attacked variables
        double knockbackAngle;//The angle in which the player is sent flying. 0 is straight horizontally, 90 is straight vertically.
        int knockbackSpeed;//The speed at which the player is sent flying.
        int knockbackDuration;//How much longer the player will be flying after being hit. 
        int hitstun;//How much longer the player will be unable to do anything after being hit.
        
        //Data Variables
        int health;//How much health the player has. Maximum: 100

        //Classes
        Rectangle playerSprite = new Rectangle();
        ImageBrush spritefill;
        BitmapImage bitmapImage;
        Hitbox hitbox = new Hitbox();
        Rect hitboxRect = new Rect();
        Canvas canvas;

        public Player(int p, Key leftBtn, Key rightBtn, Key upBtn, Key downBtn, Key punchBtn, Key kickBtn)
        {
            //store values
            player = p;
            leftButton = leftBtn;
            rightButton = rightBtn;
            upButton = upBtn;
            downButton = downBtn;
            punchButton = punchBtn;
            kickButton = kickBtn;

            //render properties
            playerSprite.Width = 128;
            playerSprite.Height = 128;
            bitmapImage = new BitmapImage(new Uri("idle.png", UriKind.Relative));//Sprites are from Street Fighter 1. I tried to make my own, but I couldn't get it to look nice.
            playerSprite.RenderTransformOrigin = new Point(0.5, 0.5);
            yPos = 280;
            if (player == 1)
            {
                xPos = 100;
                direction = 1;
            }
            if (player == 2)
            {
                
                xPos = 600;
                direction = -1;
            }

            //game data
            health = 100;
        }

        public void generate(Canvas c)
        {
            canvas = c;
            Canvas.SetLeft(playerSprite, xPos);
            Canvas.SetTop(playerSprite, yPos);
            canvas.Children.Add(playerSprite);
        }

        public void move()
        {
            if (!lag && hitstun == 0) //If player is in state to move
            {
                //Left
                if (Keyboard.IsKeyDown(leftButton))
                {
                    xPos -= 8;
                    walkAnimate += 1;
                }
                //Right
                if (Keyboard.IsKeyDown(rightButton))
                {
                    xPos += 8;
                    walkAnimate += 1;
                }
                if (!Keyboard.IsKeyDown(leftButton) && !Keyboard.IsKeyDown(rightButton))
                {
                    walkAnimate = 0;
                }

                if (!falling) //If player is on ground
                {
                    //Jump
                    if (Keyboard.IsKeyDown(upButton))
                    {
                        jump = 5;
                    }
                    //Punch
                    if (Keyboard.IsKeyDown(punchButton))
                    {
                        action = 1;
                        lag = true;
                        animation = 9;
                    }
                    //Kick
                    if (Keyboard.IsKeyDown(kickButton))
                    {
                        action = 2;
                        lag = true;
                        animation = 18;
                    }
                    //Jump
                    if (Keyboard.IsKeyDown(downButton))
                    {
                        action = 3;
                        lag = true;
                        animation = 12;
                    }
                }
            }
        }

        public void animate(double opponentX, int opponentDirection)
        {
            //Walk
            if (action == 0)
            {
                if (walkAnimate == 7) walkAnimate = 1;
                if (walkAnimate == 0) bitmapImage = new BitmapImage(new Uri("idle.png", UriKind.Relative));
                if (walkAnimate == 1) bitmapImage = new BitmapImage(new Uri("walk1.png", UriKind.Relative));
                if (walkAnimate == 2) bitmapImage = new BitmapImage(new Uri("walk2.png", UriKind.Relative));
                if (walkAnimate == 3) bitmapImage = new BitmapImage(new Uri("walk3.png", UriKind.Relative));
                if (walkAnimate == 4) bitmapImage = new BitmapImage(new Uri("walk4.png", UriKind.Relative));
                if (walkAnimate == 5) bitmapImage = new BitmapImage(new Uri("walk5.png", UriKind.Relative));
                if (walkAnimate == 6) bitmapImage = new BitmapImage(new Uri("walk6.png", UriKind.Relative));
            }

            //Jump
            if (jump > 0)
            {
                yPos -= 40;
                jump -= 1;
            }

            //Falling
            if (yPos < 280) falling = true;
            if (yPos >= 280) falling = false;
            if (falling)
            {
                yPos += 10;
                bitmapImage = new BitmapImage(new Uri("jump.png", UriKind.Relative));
            }
            else yPos = 280;

            //Actions
            if (action == 1) punch();
            if (action == 2) kick();
            if (action == 3) duck();
            if (animation > 0) animation -= 1;

            //Knocked back
            if (knockbackDuration > 0)
            {
                xPos += knockbackSpeed * (Math.Cos(knockbackAngle) * opponentDirection);
                yPos -= knockbackSpeed * Math.Sin(knockbackAngle);
            }
            if (hitstun > 0)
            {
                hitstun -= 1;
                bitmapImage = new BitmapImage(new Uri("hurt.png", UriKind.Relative));
            }
            if (knockbackDuration > 0) knockbackDuration -= 1;

            //Direction
            if (direction == 1 && xPos > opponentX) direction = -1;
            if (direction == -1 && xPos < opponentX) direction = 1; 

            //update sprite
            ScaleTransform flipTrans = new ScaleTransform();
            flipTrans.ScaleX = direction;
            playerSprite.RenderTransform = flipTrans;
            spritefill = new ImageBrush(bitmapImage);
            playerSprite.Fill = spritefill;
            if (xPos < 0) xPos = 0;
            if (xPos > 670) xPos = 670;
            Canvas.SetLeft(playerSprite, xPos);
            Canvas.SetTop(playerSprite, yPos);
        }

        public void punch()
        {
            if (animation == 9)
            {
               bitmapImage = new BitmapImage(new Uri("punch1.png", UriKind.Relative));
            }
            if (animation == 8)
            {
                bitmapImage = new BitmapImage(new Uri("punch2.png", UriKind.Relative));
            }
            if (animation == 7)
            {
                bitmapImage = new BitmapImage(new Uri("punch3.png", UriKind.Relative));
                //Add hitbox
                hitbox.generate((int)xPos + 58 + (28 * direction), (int)yPos + 48, 12, 12, 5, 20, 12, 8, 8, canvas);
                hitboxRect = hitbox.update(true);
            }
            if (animation == 6)
            {
                bitmapImage = new BitmapImage(new Uri("punch2.png", UriKind.Relative));
                //Remove hitbox
                hitboxRect = hitbox.update(false);
            }
            if (animation == 3)
            {
                bitmapImage = new BitmapImage(new Uri("punch1.png", UriKind.Relative));
            }
            if (animation == 0)
            {
                bitmapImage = new BitmapImage(new Uri("idle.png", UriKind.Relative));
                //End move
                action = 0;
                lag = false;
            }
        }

        public void kick()
        {
            if (animation == 18)
            {
                bitmapImage = new BitmapImage(new Uri("kick1.png", UriKind.Relative));
            }
            if (animation == 17)
            {
                bitmapImage = new BitmapImage(new Uri("kick2.png", UriKind.Relative));
            }
            if (animation == 14)
            {
                bitmapImage = new BitmapImage(new Uri("kick3.png", UriKind.Relative));
            }
            if (animation == 13)
            {
                bitmapImage = new BitmapImage(new Uri("kick4.png", UriKind.Relative));
                //Add hitbox
                hitbox.generate((int)xPos + 58 + (56 * direction), (int)yPos + 48, 12, 12, 10, 45, 16, 14, 12, canvas);
                hitboxRect = hitbox.update(true);
            }
            if (animation == 12)
            {
                //Remove hitbox
                hitboxRect = hitbox.update(false);
            }
            if (animation == 7)
            {
                bitmapImage = new BitmapImage(new Uri("kick3.png", UriKind.Relative));
            }
            if (animation == 5)
            {
                bitmapImage = new BitmapImage(new Uri("kick2.png", UriKind.Relative));
            }
            if (animation == 2)
            {
                bitmapImage = new BitmapImage(new Uri("kick1.png", UriKind.Relative));
            }
            if (animation == 0)
            {
                bitmapImage = new BitmapImage(new Uri("idle.png", UriKind.Relative));
                //End move
                action = 0;
                lag = false;
            }
        }

        public void duck()
        {
            if (animation == 12)
            {
                bitmapImage = new BitmapImage(new Uri("duck1.png", UriKind.Relative));
            }
            if (animation == 11)
            {
                bitmapImage = new BitmapImage(new Uri("duck2.png", UriKind.Relative));
            }
            if (animation == 10)
            {
                bitmapImage = new BitmapImage(new Uri("duck3.png", UriKind.Relative));
                ducking = true;
            }
            if (animation == 4)
            {
                bitmapImage = new BitmapImage(new Uri("duck2.png", UriKind.Relative));
                ducking = false;
            }
            if (animation == 2)
            {
                bitmapImage = new BitmapImage(new Uri("duck1.png", UriKind.Relative));
            }
            if (animation == 0)
            {
                bitmapImage = new BitmapImage(new Uri("idle.png", UriKind.Relative));
                //End move
                action = 0;
                lag = false;
            }
        }

        public void wasHit(int damage, int ka, int ks, int kd, int hs)
        {
            //Health
            health -= damage;
            if (health < 0) health = 0;

            //Knockback and hitstun
            knockbackAngle = ka;
            knockbackSpeed = ks;
            knockbackDuration = kd;
            hitstun = hs;

            //End current move
            animation = 0;
            hitboxRect = hitbox.update(false);
        }

        //Access Variables
        public double getXPos() => xPos;
        public double getYPos() => yPos;
        public Hitbox getHitbox() => hitbox;
        public Rect getHitboxRect() => hitboxRect;
        public int getHealth() => health;
        public int getDirection() => direction;
        public bool isDucking() => ducking;
    }
}
